#!/usr/bin/env python

import rospy
from std_msgs.msg import Int32

def integer_publisher():
	rospy.init_node('Publicador_p1')
	pub = rospy.Publisher('nodo_p1', Int32, queue_size=10)

	while not rospy.is_shutdown():
	    	
		user_input_str = input("Introduce un número entero (o 'salir' para terminar): ")

		if user_input_str.lower() == 'salir':
			break
			
		number_to_publish = int(user_input_str)
		msg = Int32()
		msg.data = number_to_publish

		pub.publish(msg)
		

if __name__ == '__main__':
	try:
		integer_publisher()
	except rospy.ROSInterruptException:
		pass 
