#!/usr/bin/env python

import rospy
from std_msgs.msg import Int32

def callback(msg):
	received_integer = msg.data
	print(received_integer)

def integer_subscriber():

	rospy.init_node('suscriptor_p1')
	rospy.Subscriber('nodo_p1', Int32, callback)
	rospy.spin()

if __name__ == '__main__':
	try:
		integer_subscriber()
	except rospy.ROSInterruptException:
		pass
